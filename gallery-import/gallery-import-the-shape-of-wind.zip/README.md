# 《风的形状》 / The Shape of Wind

原始导出成片原样保留：2048 × 1152，含圆角、阴影、参数标注，无 EXIF。
作品 ID（文件 SHA-256 前 24 位）：2b833398c03301dd5b121604
日期暂用本次导出/归档日 2026-11-26，非已验证拍摄日；如有准确拍摄日期请修改。

## 使用 Gallery Studio（推荐）
在仓库根目录启动 `node scripts/gallery-studio-server.mjs`，在 http://127.0.0.1:4783 导入 JPG，按 manifest.json 中的元数据填写，确认上传 R2 后审查索引。

## CLI
将本压缩包解压至仓库的同级目录 `gallery-import`（例如 C:\03_Github\gallery-import）。从仓库根目录执行：

```powershell
node scripts/gallery-studio.mjs ../gallery-import/manifest.json
node scripts/gallery-studio.mjs ../gallery-import/manifest.json --publish
```
第二条命令仅在当前进程已配置 R2 环境变量时运行；GUI 已保存的凭据不会被 CLI 自动读取。

R2 上传并确认 CDN 可读取后，审查 `src/data/gallery-photos.json`，按现有 PR 流程提交该文件。不要把本导入包、JPG 或凭据提交到 Git 仓库。
